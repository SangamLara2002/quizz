const quizData = [
    {
        question: "Q1.What is the preferred way for adding a background color in HTML?",
        a: '<body background="yellow">',
        b: "<background>yellow</background>",
        c: '< body style="background-color:yellow">',
        d: '<background color="yellow">text<background>',
        correct: "c",
    },
    {
        question:  "Q2.Which of the following JavaScript cannot do?",
        a: "JavaScript can react to events",
        b: "JavaScript can manipulate HTML elements",
        c: "JavaScript can be use to validate data",
        d: "All of the Above",
        correct: "d",
    },
    {
        question:"Q3. _________ keyword is used to declare variables in javascript.",
        a:" Var",
        b:" Dim",
        c:"String",
        d:" None of the above",
        correct: "a",
    },
    {
        question: "Q4.Which of the following options is correct with regard to HTML?",
        a: "It is a modelling language",
        b: "It is a scripting language",
        c: "It is a partial programming language",
        d: "It is used to structure documents",
        correct: "d",
    },
    {
        question:"Q5.How can you open a link in a new browser window?",
        a: '<a href="url" new>',
        b: '<a href="url" target="new">',
        c: '<a href="url" target="_blank">',
        d: '<a href="url" target="">',
        correct:"c",
    },


];

const quiz= document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')


let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {

    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer
    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })
    return answer
}


submitBtn.addEventListener('click', () => {
    const answer = getSelected()
    if(answer) {
       if(answer === quizData[currentQuiz].correct) {
           score++
       }

       currentQuiz++

       if(currentQuiz < quizData.length) {
           loadQuiz()
       } else {
           quiz.innerHTML = `
           <h2>You answered ${score}/${quizData.length} questions correctly</h2>

           <button onclick="location.reload()">Reload</button>
           `
       }
    }
})
